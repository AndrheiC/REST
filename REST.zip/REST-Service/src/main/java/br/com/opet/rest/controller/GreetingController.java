package br.com.opet.rest.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.opet.rest.exception.OpetException;
import br.com.opet.rest.exception.OpetException2;
import br.com.opet.rest.model.Greeting;

@RestController
@RequestMapping("/api/")
public class GreetingController {

    private long counter = 0;

    @GetMapping("/rest/")
    public Greeting greeting(@RequestParam("id") String name) {
        return new Greeting(counter++, "Parametro["+name+"]");
    }
    
    @PostMapping("/rest/")
    public String greeting(@RequestBody(required = true) Greeting gr) {
    	System.out.println(gr);
        return "1";
    }
    
    	
    
    @PostMapping("/rest/{id}")
    @ResponseStatus(HttpStatus.OK)
    public String greetingByID(@PathVariable("id") String id, @RequestBody(required = false) Greeting gr) {
    	System.out.println(gr + " " + id);
    	if(Integer.parseInt(id) > 10)
    		throw new OpetException();
    	if(Integer.parseInt(id) > 5)
    		throw new OpetException2();
        return "0";
    }
}
