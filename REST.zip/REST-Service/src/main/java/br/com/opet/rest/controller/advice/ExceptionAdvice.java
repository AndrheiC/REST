package br.com.opet.rest.controller.advice;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.opet.rest.exception.OpetException;
import br.com.opet.rest.exception.OpetException2;
import br.com.opet.rest.exception.ReturnException;

@ControllerAdvice
public class ExceptionAdvice {
	
	@ResponseBody
	@ExceptionHandler(value = {OpetException.class, OpetException2.class})
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ReturnException badRequestAdv(Exception var) {
		ReturnException re = new ReturnException(
				"Erro no Servico REST",
				var.getMessage());
		return re;
	}

}
