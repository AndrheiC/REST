package br.com.opet.rest.exception;

public class OpetException extends RuntimeException  {

	private static final long serialVersionUID = 5497972620149848518L;

	public OpetException() {
		super("Exception REST");
	}
	
}
