package br.com.opet.rest.exception;

public class OpetException2 extends RuntimeException  {

	private static final long serialVersionUID = -3453679017533371456L;

	public OpetException2() {
		super("Exception REST2");
	}
	
}
