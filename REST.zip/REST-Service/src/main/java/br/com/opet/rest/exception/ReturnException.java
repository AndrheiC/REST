package br.com.opet.rest.exception;

public class ReturnException {
	
	private String erro;
	private String detalhe;
	
	public ReturnException(String erro, String detalhe) {
		this.erro = erro;
		this.detalhe = detalhe;
	}
	
	public String getErro() {
		return erro;
	}
	public void setErro(String erro) {
		this.erro = erro;
	}
	public String getDetalhe() {
		return detalhe;
	}
	public void setDetalhe(String detalhe) {
		this.detalhe = detalhe;
	}

}
